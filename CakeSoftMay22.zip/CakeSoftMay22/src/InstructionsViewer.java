/**
 * Auto Generated Java Class.
 */
import javax.swing.*;
public class InstructionsViewer extends JFrame 
{
  
  /* ADD YOUR CODE HERE */
  public InstructionsViewer ()
  {
    super ("Instrucitons");
    setVisible (true);
    setSize (500,400);
    setDefaultCloseOperation (JFrame.DISPOSE_ON_CLOSE);
  }
  
}
