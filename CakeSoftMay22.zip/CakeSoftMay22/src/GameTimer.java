/**
 * Auto Generated Java Class.
 */
public class GameTimer implements Runnable {
  
  /* ADD YOUR CODE HERE */
  public void run()
  {
  }
  
}
