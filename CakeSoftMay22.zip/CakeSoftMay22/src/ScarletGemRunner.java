public class ScarletGemRunner {
  
  public static void main (String[]args)
  {
    new ScarletGemMain();
  }
  
}
