/**
 * Auto Generated Java Class.
 */
import javax.swing.*;
import java.awt.*;
public class HighScoresViewer extends JFrame 
{
  private Graphics screen;
  
  public Graphics getScreen ()
  {
    return screen;
  }
  public void setScreen (Graphics g)
  {
    screen=g;
  }
  /* ADD YOUR CODE HERE */
  
}
