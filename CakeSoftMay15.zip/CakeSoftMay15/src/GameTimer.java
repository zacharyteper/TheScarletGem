/**
 * Auto Generated Java Class.
 */
public class GameTimer  implements Runnable
{
  public void run()
  {
  }
  /* ADD YOUR CODE HERE */
  
}
