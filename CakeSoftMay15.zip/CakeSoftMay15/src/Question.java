/**
 * Auto Generated Java Class.
 */
public class Question {
  private final char answer;
  private final String question;
  
  public char getAnswer()
  {
    return answer;
  }
  public String getQuestion ()
  {
    return question;
  }
  public Question (char ans,String q)
  {
    answer=ans;
    question=q;
  }
  /* ADD YOUR CODE HERE */
  
}
