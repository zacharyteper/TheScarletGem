/**
 * Auto Generated Java Class.
 */
import javax.swing.*;
public class MainMenuPanel extends JPanel
{
  private JButton easy;
  private JButton medium;
  private JButton hard;
  private JButton loadGame;
  public JButton getEasyButton()
  {
    return easy;
  }
  public void setEasyButton(JButton b)
  {
    easy=b;
  }
  public JButton getMediumButton()
  {
    return medium;
  }
  public void setMediumButton(JButton b)
  {
    medium=b;
  }
  public JButton getHardButton()
  {
    return hard;
  }
  public void setHardButton(JButton b)
  {
    hard=b;
  }
  public JButton getLoadButton()
  {
    return loadGame;
  }
  public void setLoadButton(JButton b)
  {
    loadGame=b;
  }
  public MainMenuPanel ()
  {
    easy=new JButton ("Easy");
    medium=new JButton ("Medium");
    hard=new JButton ("Hard");
    loadGame=new JButton ("Load Game");
    
//    SpringLayout layout=new SpringLayout();
//    setLayout (layout);
    
    add(easy);
    add(medium);
    add(hard);
    add(loadGame);
    
  }
  /* ADD YOUR CODE HERE */
  
}
