/**
 * Auto Generated Java Class.
 */
import javax.swing.*;
public class InstructionsPanel extends JPanel {
  
  /* ADD YOUR CODE HERE */
  
}
